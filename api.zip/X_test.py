with open("C:\\Users\\sarth\\Downloads\\variables.index", 'rb') as f:
    data = f.read()


print(data)